from enum import Enum


class ActionSpace(Enum):
  Null = 0
  Continuous = 1
  Discrete = 2
